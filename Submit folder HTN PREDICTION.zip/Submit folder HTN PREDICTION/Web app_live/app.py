from flask import Flask,render_template,url_for,request
# EDA PKg
import numpy as np
import pandas as pd
# ML Pkg
from sklearn.externals import joblib

cindx = ['diab','cardio','bmi','waist','hip','age','salt','procfood','vigowork','modwork','walkcycle','mvsports','sedentary_min','division_Chittagong',
 'division_Dhaka','division_Khulna','division_Mymensingh','division_Rajshahi','division_Rangpur','division_Sylhet','area_Urban','gender_male',
 'educ_1Primary','educ_2Secondary','educ_3More than secondary','marital_currently married','marital_never married',
 'occup_Agriculture (land owner and farmer)','occup_Business(small/large)','occup_Government employee','occup_Home maker/ Household work',
 'occup_Labourer (Agriculture/Day/Transport/Industrial/Blacksmith/Goldsmith/Tati/domestic worker)','occup_Non-government employee',
 'occup_Retired unemployed/unable to work','occup_Student/Unemployed (able to work)','smoker_Current','smoker_Former',
 'smokeless_Current','smokeless_Former']



def MapperD(diab,cardio,waist,hip, age,salt,procfood,vigowork,modwork,walkcycle,mvsports,sedentary_min,division,area_Urban,gender_male,educ,marital,occup,smoker,smokeless,weight,height):
    diab = float(diab)
    cardio = float(cardio)
    weight = float(weight)
    height = float(height)
    bmi = weight/((height/100)**2)
    waist = float(waist)
    hip = float(hip)
    age = float(age)
    salt = float(salt)
    procfood = float(procfood)
    vigowork = float(vigowork)
    modwork = float(modwork)
    walkcycle = float(walkcycle)
    mvsports = float(mvsports)
    sedentary_min = float(sedentary_min)

    if division=="ch":
        division=[1,0,0,0,0,0,0]
    elif division=="dh":
        division=[0,1,0,0,0,0,0]
    elif division=="kh":
        division=[0,0,1,0,0,0,0]
    elif division=="my":
        division=[0,0,0,1,0,0,0]
    elif division=="raj":
        division=[0,0,0,0,1,0,0]
    elif division=="ran":
        division=[0,0,0,0,0,1,0]
    elif division=="sy":
        division=[0,0,0,0,0,0,1]
    else:
        division=[0,0,0,0,0,0,0]

    area_Urban = float(area_Urban)
    gender_male = float(gender_male)
    if educ=="pri":
        educ = [1,0,0]
    elif educ=="sec":
        educ = [0,1,0]
    elif educ=="more":
        educ = [0,0,1]
    else:
        educ = [0,0,0]

    if marital=="cm":
        marital = [1,0]
    elif marital=="nm":
        marital = [0,1]
    else:
        marital = [0,0]

    if occup == "1":
        occup = [1,0,0,0,0,0,0,0]
    elif occup == "2":
        occup = [0,1,0,0,0,0,0,0]
    elif occup == "3":
        occup = [0,0,1,0,0,0,0,0]
    elif occup == "4":
        occup = [0,0,0,1,0,0,0,0]
    elif occup == "5":
        occup = [0,0,0,0,1,0,0,0]
    elif occup == "6":
        occup = [0,0,0,0,0,1,0,0]
    elif occup == "7":
        occup = [0,0,0,0,0,0,1,0]
    elif occup == "8":
        occup = [0,0,0,0,0,0,0,1]
    else:
        occup = [0,0,0,0,0,0,0,0]

    if smoker=="cur":
        smoker=[1,0]
    elif smoker=="for":
        smoker=[0,1]
    else:
        smoker=[0,0]

    if smokeless=="cur":
        smokeless=[1,0]
    elif smokeless=="for":
        smokeless=[0,1]
    else:
        smokeless=[0,0]

    sample_data = [diab,cardio,bmi,waist,hip,age,salt,procfood,vigowork,modwork,walkcycle,mvsports,sedentary_min]+division+[area_Urban,gender_male]+educ+marital+occup+smoker+smokeless
    sample_data = pd.DataFrame(sample_data, index=cindx)
    sample_data = sample_data.T
    sample_data[['bmi','waist','hip','age','salt','procfood','sedentary_min']] = sc.transform(sample_data[['bmi','waist','hip','age','salt','procfood','sedentary_min']])
    return sample_data

def RiskReport(x):
    x = x*100
    x = int(x)
    if x < 2000:
        msg = "alert alert-success"
        grp = "very low"
    elif (x >= 2000) & (x < 4000):
        msg = "alert alert-primary"
        grp = "low"
    elif (x >= 4000) & (x < 6000):
        msg = "alert alert-secondary"
        grp = "medium"
    elif (x >= 6000) & (x < 8000):
        msg = "alert alert-warning"
        grp = "high"
    else:
        msg = "alert alert-danger"
        grp = "very high"

    return [msg, grp]


app = Flask(__name__)
app.config['SECRET_KEY'] = 'In the name of Allah'

fvalid = False

svm_model = joblib.load('data/SVM.pkl')
sc = joblib.load('data/sc.pkl')

@app.route('/')
def index():
    return render_template("index.html",fvalid=fvalid, inclass=None, riskpred=None, riskgroup=None)


@app.route('/',methods=["POST"])
def analyze():
    if request.method == 'POST':
        age = request.form['age']
        gender = request.form['gender']
        division = request.form['division']
        area = request.form['area']
        marital = request.form['marital']
        occup = request.form['occup']
        educ = request.form['educ']
        diab = request.form['diab']
        cardio = request.form['cardio']
        height = request.form['height']
        weight = request.form['weight']
        waist = request.form['waist']
        hip = request.form['hip']
        salt = request.form['salt']
        procfood = request.form['procfood']
        vigowork = request.form['vigowork']
        modwork = request.form['modwork']
        walkcycle = request.form['walkcycle']
        mvsports = request.form['mvsports']
        sedentary = request.form['sedentary']
        smoker = request.form['smoker']
        smokeless = request.form['smokeless']
        fvalid = True
        response = MapperD(diab=diab,cardio=cardio,waist=waist,hip=hip, age=age,salt=salt,procfood=procfood,vigowork=vigowork,modwork=modwork,walkcycle=walkcycle,mvsports=mvsports,sedentary_min=sedentary,division=division,area_Urban=area,gender_male=gender,educ=educ,marital=marital,occup=occup,smoker=smoker,smokeless=smokeless,weight=weight,height=height)
        riskpred = round(svm_model.predict_proba(response)[0,1]*100,2)
        riskgroup = RiskReport(x=riskpred)[1]
    return render_template('index.html',fvalid=fvalid, riskpred=riskpred, riskgroup=riskgroup)

if __name__ == '__main__':
    app.run(debug=False)
